<?php
	ini_set('date.timezone','Asia/Shanghai');
	session_start();
	error_reporting(E_ERROR);


	$db_host = 'localhost';
	$db_user = 'pay_hdphp_com';
	$db_passwd = 'NAw8KnCZyy';
	$db_name = 'pay_hdphp_com';
	$conn = mysqli_connect($db_host, $db_user, $db_passwd,$db_name) ;
	if (!$conn){
		die('Could not connect: ' . mysqli_error());
	}
//	//execute the query.
//	$result = mysqli_query($conn, $query);
//	//display information:
//	while($row = mysqli_fetch_array($result)) {
//		var_dump($row);
//	}
//	mysqli_close($conn);
	return $conn;
?>