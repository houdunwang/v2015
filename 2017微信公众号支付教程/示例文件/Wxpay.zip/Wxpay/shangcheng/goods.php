<?php 
require_once "./config.php";
require_once "../lib/WxPay.Api.php";
require_once "../example/WxPay.JsApiPay.php";

$id = $_GET['id'];
$sql = "SELECT * FROM ceshitable WHERE id = {$id}";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);

//②、统一下单  out_trade_no、body、total_fee、trade_type、openid必填
$input = new WxPayUnifiedOrder();
$input->SetBody($row['title']);
//$input->SetAttach("test");
$input->SetOut_trade_no(WxPayConfig::MCHID.date("YmdHis").mt_rand(0,9999));
$input->SetTotal_fee($row['price'] * 100);
//$input->SetTime_start(date("YmdHis"));
//$input->SetTime_expire(date("YmdHis", time() + 600));
//$input->SetGoods_tag("test");
$input->SetNotify_url("http://pay.hdphp.com/Wxpay/example/notify.php");
$input->SetTrade_type("JSAPI");
$input->SetOpenid($_SESSION['openid']);
$order = WxPayApi::unifiedOrder($input);


$tools = new JsApiPay();
$jsApiParameters = $tools->GetJsApiParameters($order);

?>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
    <title>微信JSAPI支付</title>
    <link rel="stylesheet" href="css/swiper.min.css?ver=<?=rand(0,99999)?>">
    <link rel="stylesheet" href="css/shop.css?ver=<?=rand(0,9999)?>"/>
	<script src="js/jquery.min.js"></script>
	<script src="js/swiper.min.js?ver=<?=rand(0,99999)?>"></script>
	<style type="text/css">
		*{margin: 0;padding: 0;}
		.header-img {width: 100%; height: auto;}
		.header-img img{ display:block; margin:0px;}
		.line{width: 100%;height: 10px;background: #CCCCCC;}
	</style>
    <script type="text/javascript">
	//调用微信JS api 支付
	function weixinpay(){
		 WeixinJSBridge.invoke(
	       'getBrandWCPayRequest', <?php echo $jsApiParameters; ?>,
	       	function(res){     
	           if(res.err_msg == "get_brand_wcpay_request:ok" ) {
	           		location.href = "success.php?id=<?php echo $row['id']; ?>"
	           }else if(res.err_msg == "get_brand_wcpay_request:cancel"){
	           		alert('取消支付');
	           }else{
	           		alert('支付失败');
	           }
	           // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。 
	       }
	   ); 
	}
	</script>
</head>
<body>
	<div class='header-img'><img src='./<?=$row['titleimg']?>' alt='' style='width:100%'></div>
	<div class="line"></div>
	<div class="goods">
		<p class="goodsname">
			<?php echo $row['title']; ?>
		</p>
		<p class="summary">
			<?php echo $row['desc']; ?>
		</p>
		<p class="price">
			<span style="width: 25%;color: black;">支付金额：</span>
			<span style="width: 20%;margin-right: 2%;display: inline-block;text-align: center;" class="spprice">¥<?php echo $row['price']; ?></span>
			<input type="hidden" name="price" value="<?php echo $row['price']; ?>">
		</p>
		<p class="jieshao">
			<span style="width: 25%;color: black;">简单介绍：</span>
			<span style="width: 100%;margin-right: 2%;display: inline-block;text-align: left;" class="spprice"><?php echo $row['content']; ?></span>
		</p>
	</div>
    <br/>
	<div align="center">
		<button style="width:100%; height:50px;background-color:#FE6714; border:0px #FE6714 solid; cursor: pointer;  color:white;  font-size:16px;position: fixed;bottom: 0;left: 0;" type="button" onclick="weixinpay();" >立即支付</button>
	</div>
</body>
</html>



