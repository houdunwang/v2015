﻿var mobileCheckPars = /^(1[3-9][0-9]{9})$/;
var isSubmitting=false;

$(document).ready(function(){
	$(".funcmenu").click(function(){
		showSideMenu();
	});
	$(".backmenu").click(function(){
		if (window.history.length>1)
		{
			history.back();
		}
		else
		{
			wx.closeWindow();
		}
	});
	$(".sidemenu").click(function(){
		closeSideMenu()
	});
});

function showSideMenu()
{
	$(".sidemenu").fadeIn();
}

function closeSideMenu()
{
	$(".sidemenu").fadeOut();
}

function logout()
{
	if (isSubmitting) return false;
	isSubmitting=true;
	$.ajax(
	{
		type: 'POST',
		dataType: 'json',
		url: 'api/dataopt.php',
		data: { action:'memberlogout' },
		success: function (data) {
			isSubmitting=false;
			if (data.result==1)
			{
				location.href="login.php";
			}
			else
			{
				$.toast(data.message, "forbidden");
			}
		},
		error: function (msg, textStatus, e) {
			btnLocked=false;
			$.toast("通信失败！", "forbidden");
		}
	});
}

function getInCart()
{
	
	$.ajax({
		type: "post",
		cache: false,
		dataType: "json",
		url: "api/dataopt.php",
		data: { action: "cartget" },
		success: function (response) {
			incart=parseInt(response.incart);
			$("#cartnum").html(response.incart);
			if (incart>0)
			{
				$("#cartnum").show();
			}
			else
			{
				$("#cartnum").hide();
			}
		},
		error:function (response) {
			$.toast("网络连接失败", "forbidden");
		}
	});
}
