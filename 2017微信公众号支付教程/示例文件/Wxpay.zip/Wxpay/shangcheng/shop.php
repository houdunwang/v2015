<?php 
require_once "./config.php";
require_once "../lib/WxPay.Api.php";
require_once "../example/WxPay.JsApiPay.php";
//1.获取用户的openid
$tools = new JsApiPay();
$openId = $tools->GetOpenid();
if(!isset($_SESSION['openid'])){
	$_SESSION['openid'] = $openId;
}

?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
    <title>微信JSAPI支付</title>
    <link rel="stylesheet" href="css/weui.min.css?ver=<?=rand(0,9999)?>"/>
    <link rel="stylesheet" href="css/shop.css?ver=<?=rand(0,9999)?>"/>
    <script src="js/jquery.min.js"></script>
</head>
<body>
	<header class="pageheader">
		官方商城
	</header>
	<div class="goodslistbox">
		<ul class="goodslist">
		<?php
			$sql = "SELECT * FROM ceshitable";
			$result = mysqli_query($conn,$sql);
	        while ($row = mysqli_fetch_assoc($result))
	        {
	    ?>
	        <li>
	            <a href="goods.php?id=<?php echo $row['id']?>">
	                <div class="goodsinfo">
	                    <span class="headimg" style="background:url('./<?=$row['titleimg']?>') center center no-repeat; background-size:cover;">
	                    <img class='soldout' src='images/tag3.png'>
	                    </span>
	                    <p class="goodsname"><?=$row['title']?></p>
	                    <p class="summary"><?=$row['desc']?></p>
	                    <p class="price">
	                		<span>¥<?=$row['price']?></span>
	                    </p>
	                </div>
	            </a>
	        </li>
	    <?php
	        }
	    ?>
	    </ul>
	</div>
</body>
</html>