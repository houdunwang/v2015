<?php 
require_once "./config.php";

$id = $_GET['id'];
$sql = "SELECT * FROM ceshitable WHERE id = $id";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);

?>
<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<title>微信JSAPI支付</title>
	<link rel="stylesheet" href="css/weui.min.css?ver=<?=rand(0,9999)?>"/>
    <link rel="stylesheet" href="css/shop.css?ver=<?=rand(0,9999)?>"/>
    <style type="text/css">
    	.info{
    		width: 100%;
    	}
    	.info p{
			margin-left:10px;
			height:50px;
			line-height:50px;
			text-align:left;
			color:#666;
			position:relative;
			font-size:16px;
			overflow: hidden;
		    text-overflow: ellipsis;
		    display: -webkit-box;
		    -webkit-box-orient: vertical;
		    -webkit-line-clamp: 2;
    	}
    </style>
</head>
<body>
	<header class="pageheader">
		购买成功！
	</header>
	<div class="info">
		<p class="title">
			商品名称：<?php echo $row['title']; ?>
		</p>
		<p class="desc">
			商品描述：<?php echo $row['desc']; ?>
		</p>
		<p class="price">
			商品价格：<?php echo $row['price']; ?>
		</p>
		
	</div>
</body>
</html>