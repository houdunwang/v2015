<?php
return array (
  'admin_email' => 'phpcms@phpcms.cn',
  'maxloginfailedtimes' => '8',
  'minrefreshtime' => '2',
  'mail_type' => '1',
  'mail_server' => 'smtp.qq.com',
  'mail_port' => '25',
  'category_ajax' => '0',
  'mail_user' => '704311329@qq.com',
  'mail_auth' => '0',
  'mail_from' => '1004172436@qq.com',
  'mail_password' => 'ljy150220',
  'errorlog_size' => '20',
);
?>