<?php
return array (
  5 => 
  array (
    0 => 1,
  ),
);
?>