<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '后盾人 人人做后盾 houdunren.com',
    'dirname' => '',
    'domain' => 'http://localhost/my-video/phpcms/',
    'site_title' => '后盾人 人人做后盾 houdunren.com',
    'keywords' => '后盾人,后盾网,后盾论坛,后盾php, houdunren.com',
    'description' => '后盾网隶属于北京后盾计算机技术培训有限责任公司，是专注于培养中国互联网顶尖PHP程序语言专业人才的专业型培训机构，拥有七年培训行业经验。后盾网拥有国内最顶尖的讲师和技术团队，团队成员项目经验均在8年以上，团队曾多次为国内外上市集团、政府机关的大型项目提供技术支持，其中包括新浪、搜狐、腾讯、宝洁公司、联想、丰田、工商银行、中国一汽等众多大众所熟知的知名企业。 houdunren.com',
    'release_point' => '',
    'default_style' => 'houdunwang',
    'template' => 'houdunwang',
    'setting' => '{"upload_maxsize":"4096","upload_allowext":"jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|swf","watermark_enable":"1","watermark_minwidth":"300","watermark_minheight":"300","watermark_img":"statics\\/images\\/water\\/\\/mark.png","watermark_pct":"85","watermark_quality":"80","watermark_pos":"9"}',
    'uuid' => '3555e035-c9d9-11e7-bc12-28d2443e2477',
    'url' => 'http://localhost/my-video/phpcms/',
  ),
);
?>