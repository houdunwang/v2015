<?php
return array (
  14 => 
  array (
    'typeid' => '55',
    'name' => '产品模型',
    'sort' => '0',
  ),
  1 => 
  array (
    'typeid' => '1',
    'name' => '新闻',
    'sort' => '1',
  ),
  3 => 
  array (
    'typeid' => '3',
    'name' => '图片',
    'sort' => '2',
  ),
  2 => 
  array (
    'typeid' => '2',
    'name' => '下载',
    'sort' => '3',
  ),
  'special' => 
  array (
    'typeid' => '52',
    'name' => '专题',
  ),
);
?>