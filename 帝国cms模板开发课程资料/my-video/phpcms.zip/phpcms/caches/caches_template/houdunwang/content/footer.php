<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="share">
    <div class="center">
        <div class="left" style="line-height: 40px;">
            <img src="<?php echo WEB_PATH;?>statics/houdunwang/images/houdunwang.png" alt="">
        </div>
        <!--<div class="right bdsharebuttonbox">-->
        <!--<span>分享至</span>-->
        <!--<a href="#" class="bds_sqq qq" data-cmd="sqq" title="分享到QQ"></a>-->
        <!--<a href="#" class="bds_weixin weixin" data-cmd="weixin" title="分享到微信"></a>-->
        <!--<a href="#" class="bds_qzone qzone" data-cmd="qzone" title="分享到QQ空间"></a>-->
        <!--<a href="#" class="bds_weixin friend" data-cmd="tieba" title="分享到百度贴吧"></a>-->
        <!--<a href="#" class="bds_tsina tsina" data-cmd="tsina" title="分享到新浪微博"></a>-->
        <!--<a href="#" class="bds_tqq tqq" data-cmd="tqq" title="分享到腾讯微博"></a>-->
        <!--</div>-->
    </div>
</div>

<!-- 底部区域 -->
<div class="foot">
    <div class="center">
        <div class="company">
            <p class="title">The Company</p>
            <ul>
                <li><a href="http://www.houdunwang.com/">实战培训</a></li>
                <li><a href="http://www.houdunren.com/">在线视频</a></li>
                <li><a href="http://bbs.houdunwang.com/portal.php">论坛讨论</a></li>
                <li><a href="#">关于我们</a></li>
            </ul>
        </div>
        <div class="lianxi">
            <p class="title">Contact</p>
            <ul>
                <li><a href="http://houdunren.com" target="_blank">houdunren.com</a></li>
                <li>400-682-3231</li>
            </ul>
        </div>
        <div class="address">
            <p class="title">Address</p>
            <ul>
                <li>北京市朝阳区马泉营</li>
                <li>顺白路12号</li>
                <li>比目鱼创业园A区</li>
            </ul>
        </div>
        <div class="follow">
            <p class="title">Follow Us</p>
            <a href="javascript:void(0);" class="tsina" title="马上就要放大招了，敬请期待~"></a>
            <a href="javascript:void(0);" class="gzweixin" title=""></a>
        </div>
        <div class="gzherweima">
            <img src="<?php echo WEB_PATH;?>statics/houdunwang/images/gongzhonghao.jpg" alt="">
            <p>扫一扫，关注后盾</p>
        </div>
    </div>
</div>
<!-- 底部区域 -->