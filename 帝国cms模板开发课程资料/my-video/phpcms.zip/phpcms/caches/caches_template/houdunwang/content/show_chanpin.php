<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv=“X-UA-Compatible” content=“chrome=1″ />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="renderer" content="webkit" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <title><?php echo $title;?></title>
    <link rel="stylesheet" href="<?php echo WEB_PATH;?>statics/houdunwang/css/reset.css">
    <link rel="stylesheet" href="<?php echo WEB_PATH;?>statics/houdunwang/css/common.css">
    <script type="text/javascript" src="<?php echo WEB_PATH;?>statics/houdunwang/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo WEB_PATH;?>statics/houdunwang/js/common.js"></script>
    <script type="text/javascript" src="<?php echo WEB_PATH;?>statics/houdunwang/js/scrollTop.js"></script>
</head>
<body>
<?php include template('content','header'); ?>
<div class="clear"></div>
<!-- 头部结束 -->
<div class="sjheader">
    <div class="left">
        <a href="http://www.yimaokeji.com/"><img src="http://www.yimaokeji.com/statics/ymkj/images/mobile/logo.png" alt=""></a>
    </div>
    <div class="center"></div>
    <!-- <div class="right">
        <img src="http://www.yimaokeji.com/statics/ymkj/images/mobile/menu.png" alt="">
    </div> -->
    <!-- 手机菜单 -->
    <div class="menu">
        <a href="#menu" class="glyphicon glyphicon-th-list">
        </a>
    </div>
    <!-- 手机菜单 -->
</div>


<!-- 手机头部结束 --><link rel="stylesheet" href="<?php echo WEB_PATH;?>statics/houdunwang/css/chanpin.css">


<!-- 产品开始 -->
<div class="details">
    <div class="chanpin">
        <div class="ziliao">
            <!--<img src="<?php echo WEB_PATH;?>statics/houdunwang/images/houdunren.png" alt="">-->
            <div class="left">
                <img src="<?php echo $thumb;?>" style="margin-top:50px;">
            </div>
            <div class="right">
                <p class="lmm"><img src="<?php echo WEB_PATH;?>statics/houdunwang/images/chanpinTitle1.png" alt=""></p>
                <p class="title"><?php echo $title;?></p>

            </div>
        </div>
    </div>
    <div class="xiangqing">
        <?php echo $content;?>
    </div>
</div>
<div class="clear"></div>
<!-- 产品结束 -->
<?php include template('content','footer'); ?>
<!-- 底部区域 -->
<!-- 手机版本menu -->
<link type="text/css" rel="stylesheet" href="http://www.yimaokeji.com/statics/ymkj/css/jquery.mmenu.all.css" />
<script type="text/javascript" src="http://www.yimaokeji.com/statics/ymkj/js/jquery.mmenu.all.min.js"></script>
<script>
    window._bd_share_config = {
        "common": {
            "bdSnsKey": {},
            "bdText": "",
            "bdMini": "2",
            "bdMiniList": false,
            "bdPic": "",
            "bdStyle": "0",
            "bdSize": "16"
        },
        "share": {},
        // "image": {
        // 	"viewList": ["sqq", "weixin", "qzone", "tieba", "tsina", "tqq"],
        // 	"viewText": "分享到：",
        // 	"viewSize": "16"
        // },
        // "selectShare": {
        // 	"bdContainerClass": null,
        // 	"bdSelectMiniList": ["sqq", "weixin", "qzone", "tieba", "tsina", "tqq"]
        // }
    };
    with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~(-new Date() / 36e5)];
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("nav#menu").mmenu({
            offCanvas: {
                position: "right",
                zposition : "front"
            }
        });
        $(".gzweixin").hover(function(){
            var height = document.documentElement.clientHeight;
            $(".gzherweima").css('bottom',(height - 200) / 2);
            $(".gzherweima").css('display','block');
        },function(){
            $(".gzherweima").css('display','none');
        });
    });
</script>
<a href="#" class="bds_sqq qq" data-cmd="sqq" title="分享到QQ"></a>
<a href="#" class="bds_weixin weixin" data-cmd="weixin" title="分享到微信"></a>
<a href="#" class="bds_qzone qzone" data-cmd="qzone" title="分享到QQ空间"></a>
<a href="#" class="bds_weixin friend" data-cmd="tieba" title="分享到百度贴吧"></a>
<a href="#" class="bds_tsina tsina" data-cmd="tsina" title="分享到新浪微博"></a>
<a href="#" class="bds_tqq tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
</div>
</div>
<script>
    window._bd_share_config = {
        "common": {
            "bdSnsKey": {},
            "bdText": "",
            "bdMini": "2",
            "bdMiniList": false,
            "bdPic": "",
            "bdStyle": "0",
            "bdSize": "16"
        },
        "share": {},
        // "image": {
        // 	"viewList": ["sqq", "weixin", "qzone", "tieba", "tsina", "tqq"],
        // 	"viewText": "分享到：",
        // 	"viewSize": "16"
        // },
        // "selectShare": {
        // 	"bdContainerClass": null,
        // 	"bdSelectMiniList": ["sqq", "weixin", "qzone", "tieba", "tsina", "tqq"]
        // }
    };
    with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~(-new Date() / 36e5)];
</script></body>
</html>