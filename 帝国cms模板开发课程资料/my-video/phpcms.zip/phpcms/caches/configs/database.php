<?php

return array (
	'default' => array (
		'hostname' => 'localhost',
		'port' => 3306,
		'database' => 'phpcms',
		'username' => 'root',
		'password' => 'root',
		'tablepre' => 'v9_',
		'charset' => 'utf8',
		'type' => 'mysqli',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>