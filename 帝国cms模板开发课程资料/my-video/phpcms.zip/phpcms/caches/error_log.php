<?php exit;?>11-15 15:44:11 | 2 | mysqli::mysqli(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) | phpcms\libs\classes\db_mysqli.class.php | 55
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>11-15 15:44:11 | 2 | mysqli::close(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 409
<?php exit;?>11-15 15:44:11 | 2 | mysqli::mysqli(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) | phpcms\libs\classes\db_mysqli.class.php | 55
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>11-15 15:44:11 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/14965040114aa2e65.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/1496504064bcb40631.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/14965041821ae8a617.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/149650418269fd7476.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/1496504182eb292413.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/149650418386385577.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/1496504183c0b2b258.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/1496504229c69c0268.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/149650422938297764.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-17 17:26:33 | 2 | copy(http://oss.houdunren.com/14965042294ce2e35.JPG): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 01:58:16 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c1c29d.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 01:58:16 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c3cee6.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 01:58:16 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c58f31.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 01:58:16 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c71c08.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 01:58:16 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c89aba.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 01:58:16 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24ca464b.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 01:58:16 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24cbc2d8.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 02:04:03 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c1c29d.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 02:04:03 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c3cee6.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 02:04:03 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c58f31.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 02:04:03 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c71c08.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 02:04:03 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24c89aba.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 02:04:03 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24ca464b.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-24 02:04:03 | 2 | copy(http://localhost/https:/box.kancloud.cn/2016-08-17_57b3e24cbc2d8.png): failed to open stream: HTTP request failed! HTTP/1.1 403 Forbidden
 | phpcms\libs\classes\attachment.class.php | 175
<?php exit;?>11-29 02:28:05 | 2 | Missing argument 2 for category::delete_child(), called in E:\phpStudy\WWW\my-video\phpcms\phpcms\modules\admin\category.php on line 351 and defined | phpcms\modules\admin\category.php | 346
