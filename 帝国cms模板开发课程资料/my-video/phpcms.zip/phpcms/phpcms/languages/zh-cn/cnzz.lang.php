<?php
$LANG['reg_msg'] = '您还的网站还没有申请CNZZ统计，是否现在申请？<br><br><input type="button" onclick="location.href=\'?m=cnzz&c=index&a=public_regcnzz\'" value=" 马 上 开 通 "> <input type="button" onclick="history.back();" value=" 暂 不 开 通 ">';
$LANG['application_fails'] = '申请失败，请稍候再试。';
$LANG['donot_connect_server'] = '无法成功连接cnzz服务器。';
$LANG['has_been_registered'] = '已经注册过。';