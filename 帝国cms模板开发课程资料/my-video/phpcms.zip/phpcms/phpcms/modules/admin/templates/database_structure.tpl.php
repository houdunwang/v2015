<?php
defined('IN_ADMIN') or exit('No permission resources.');
include $this->admin_tpl('header');?>
<div class="pad_10">
<div class="table-list">
<xmp><?php echo $structure?></xmp>
</div>
</div>
</body>
</html>