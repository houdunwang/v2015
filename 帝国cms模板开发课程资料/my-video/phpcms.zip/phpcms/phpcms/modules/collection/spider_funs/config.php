<?php
defined('IN_PHPCMS') or exit('No permission resources.');
$spider_funs = array(
'trim'=>'过滤空格',
'spider_photos'=>'处理为组图',
'spider_downurls'=>'处理为下载列表',
'spider_keywords'=>'获取关键字',
);