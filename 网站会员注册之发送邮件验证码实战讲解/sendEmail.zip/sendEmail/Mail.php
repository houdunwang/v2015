<?php
/**
 * Created by PhpStorm.
 * User: mazhenyu
 * Date: 17/10/2017
 * Time: 20:47
 * Email: 410004417@qq.com
 */
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
class Mail {
	public $ErrorInfo;

	public function send($address,$content){
		$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
		try {
			$mail->CharSet = 'UTF-8';
			//Server settings
//			$mail->SMTPDebug = 2;                                 // Enable verbose debug output
			$mail->isSMTP();                                      // Set mailer to use SMTP
			$mail->Host = 'smtp.163.com';  // Specify main and backup SMTP servers
			$mail->SMTPAuth = true;                               // Enable SMTP authentication
			$mail->Username = 'houdunrenemail1@163.com';                 // SMTP username
			$mail->Password = 'houdunren123';                           // SMTP password
			$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
			$mail->Port = 994;                                    // TCP port to connect to

			//Recipients
			$mail->setFrom('houdunrenemail1@163.com', '后盾人');
//			$mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient
			$mail->addAddress($address);               // Name is optional
//			$mail->addReplyTo('info@example.com', 'Information');
//			$mail->addCC('cc@example.com');
//			$mail->addBCC('bcc@example.com');

			//Attachments
//			$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//			$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			//Content
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = '后盾人验证码';
			$mail->Body    = $content;
//			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			$mail->send();
			return true;
//			echo 'Message has been sent';
		} catch (Exception $e) {
//			echo 'Message could not be sent.';
//			echo 'Mailer Error: ' . $mail->ErrorInfo;
			$this->ErrorInfo = $mail->ErrorInfo;
			return false;
		}
	}
}