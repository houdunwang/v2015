<?php
/**
 * Created by PhpStorm.
 * User: mazhenyu
 * Date: 17/10/2017
 * Time: 21:00
 * Email: 410004417@qq.com
 */
session_id() || session_start();
include './vendor/autoload.php';
function p($var){
	echo '<pre>';
	print_r($var);
	echo '</pre>';
}
class HomeController{
	/**
	 * 默认首页
	 */
	public function index(){
		include './template/index.php';
	}

	public function sendCaptcha(){
		include './Mail.php';
		$mail = new Mail();
		//随机验证码
		$captcha = substr(md5(microtime(true)),0,4);
		$_SESSION['captcha'] = $captcha;
		$_SESSION['email'] = $_POST['email'];
		$_SESSION['savetime'] = time();


		$bool = $mail->send($_POST['email'],'后盾人注册验证码：' . $captcha . ' 千万不要告诉别人哦！^_^');
		if($bool){
			echo json_encode(['errorno'=>0,'errormsg'=>'ok']);
		}else{
			//p($mail->ErrorInfo);
			echo json_encode(['errorno'=>908,'errormsg'=>'请联系管理员410004417@qq.com']);
		}
	}

	public function reg(){
		if($_SESSION['email'] == $_POST['email'] && strtolower($_SESSION['captcha']) == strtolower($_POST['captcha']) && $_SESSION['savetime'] + 30 > time()){
			echo 'yes';
		}else{
			echo 'no';
		}
	}

}
//?a=index
$action = isset($_GET['a']) ? $_GET['a'] : 'index';
$controller = new HomeController();
$controller->$action();
