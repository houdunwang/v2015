SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

DROP SCHEMA IF EXISTS `hdgroup` ;
CREATE SCHEMA IF NOT EXISTS `hdgroup` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `hdgroup` ;

-- -----------------------------------------------------
-- Table `hdgroup`.`group_shop`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_shop` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_shop` (
  `shopid` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `shopname` VARCHAR(30) NOT NULL DEFAULT '' COMMENT '商品名称' ,
  `shopaddress` VARCHAR(120) NOT NULL DEFAULT '' COMMENT '商铺地址' ,
  `metroaddress` VARCHAR(120) NOT NULL DEFAULT '' COMMENT '地铁地址' ,
  `shoptel` CHAR(12) NOT NULL COMMENT '商铺电话' ,
  `shopcoord` VARCHAR(60) NOT NULL DEFAULT '' COMMENT '商铺坐标' ,
  PRIMARY KEY (`shopid`) ,
  UNIQUE INDEX `shopid_UNIQUE` (`shopid` ASC) )
ENGINE = InnoDB
COMMENT = '商铺表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_category`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_category` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_category` (
  `cid` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `cname` CHAR(20) NOT NULL DEFAULT '' COMMENT '分类名称' ,
  `keywords` VARCHAR(120) NOT NULL DEFAULT '' COMMENT '分类关键字' ,
  `title` VARCHAR(60) NOT NULL DEFAULT '' COMMENT '分类标题' ,
  `description` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '分类描述' ,
  `sort` SMALLINT UNSIGNED NOT NULL COMMENT '排序' ,
  `display` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '是否显示' ,
  `pid` SMALLINT UNSIGNED NOT NULL DEFAULT 0 ,
  PRIMARY KEY (`cid`) ,
  UNIQUE INDEX `cid_UNIQUE` (`cid` ASC) ,
  UNIQUE INDEX `cname_UNIQUE` (`cname` ASC) )
ENGINE = InnoDB
COMMENT = '分类表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_locality`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_locality` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_locality` (
  `lid` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `lname` CHAR(20) NULL DEFAULT '' ,
  `pid` SMALLINT UNSIGNED NULL DEFAULT 0 ,
  `sort` SMALLINT UNSIGNED NULL DEFAULT 0 COMMENT '排序' ,
  `display` TINYINT NULL DEFAULT 1 COMMENT '是否显示' ,
  PRIMARY KEY (`lid`) ,
  UNIQUE INDEX `lid_UNIQUE` (`lid` ASC) ,
  UNIQUE INDEX `lname_UNIQUE` (`lname` ASC) ,
  UNIQUE INDEX `pid_UNIQUE` (`pid` ASC) ,
  UNIQUE INDEX `sort_UNIQUE` (`sort` ASC) ,
  UNIQUE INDEX `display_UNIQUE` (`display` ASC) )
ENGINE = InnoDB
COMMENT = '地区表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_goods`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_goods` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_goods` (
  `gid` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '商品主键' ,
  `shopid` SMALLINT UNSIGNED NOT NULL ,
  `cid` SMALLINT UNSIGNED NOT NULL ,
  `lid` SMALLINT UNSIGNED NOT NULL ,
  `main_title` VARCHAR(30) NOT NULL DEFAULT '' COMMENT '商品主标题' ,
  `sub_title` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '商品副标题' ,
  `price` DECIMAL(7,1) NOT NULL DEFAULT 0 COMMENT '商品价格' ,
  `old_price` DECIMAL(7,1) NOT NULL DEFAULT 0 COMMENT '原价' ,
  `buy` SMALLINT NOT NULL DEFAULT 0 COMMENT '购买人数' ,
  `goods_img` VARCHAR(60) NOT NULL COMMENT '商品图' ,
  PRIMARY KEY (`gid`) ,
  UNIQUE INDEX `gid` (`gid` ASC) ,
  INDEX `fk_group_goods_group_shop_idx` (`shopid` ASC) ,
  INDEX `fk_group_goods_group_category1_idx` (`cid` ASC) ,
  INDEX `fk_group_goods_group_locality1_idx` (`lid` ASC) ,
  CONSTRAINT `fk_group_goods_group_shop`
    FOREIGN KEY (`shopid` )
    REFERENCES `hdgroup`.`group_shop` (`shopid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_goods_group_category1`
    FOREIGN KEY (`cid` )
    REFERENCES `hdgroup`.`group_category` (`cid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_goods_group_locality1`
    FOREIGN KEY (`lid` )
    REFERENCES `hdgroup`.`group_locality` (`lid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '商品表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_user`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_user` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_user` (
  `uid` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `email` VARCHAR(32) NOT NULL COMMENT '邮箱' ,
  `uname` CHAR(16) NOT NULL COMMENT '用户名' ,
  `password` CHAR(32) NOT NULL COMMENT '密码' ,
  `phone` CHAR(11) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX `uid_UNIQUE` (`uid` ASC) ,
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) ,
  UNIQUE INDEX `uname_UNIQUE` (`uname` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hdgroup`.`group_order`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_order` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_order` (
  `user_id` INT UNSIGNED NOT NULL ,
  `goods_id` INT UNSIGNED NOT NULL ,
  `goods_num` SMALLINT NOT NULL ,
  `orderid` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '订单id' ,
  `total_money` SMALLINT NOT NULL COMMENT '总金额' ,
  INDEX `fk_group_user_has_group_goods_group_goods1_idx` (`goods_id` ASC) ,
  INDEX `fk_group_user_has_group_goods_group_user1_idx` (`user_id` ASC) ,
  PRIMARY KEY (`orderid`) ,
  UNIQUE INDEX `orderid_UNIQUE` (`orderid` ASC) ,
  CONSTRAINT `fk_group_user_has_group_goods_group_user1`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_user_has_group_goods_group_goods1`
    FOREIGN KEY (`goods_id` )
    REFERENCES `hdgroup`.`group_goods` (`gid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '用户订单表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_comment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_comment` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_comment` (
  `user_id` INT UNSIGNED NOT NULL ,
  `goods_id` INT UNSIGNED NOT NULL ,
  `time` INT NOT NULL COMMENT '评论时间' ,
  `content` VARCHAR(255) NOT NULL COMMENT '评论内容' ,
  INDEX `fk_group_user_has_group_goods_group_goods3_idx` (`goods_id` ASC) ,
  INDEX `fk_group_user_has_group_goods_group_user3_idx` (`user_id` ASC) ,
  CONSTRAINT `fk_group_user_has_group_goods_group_user3`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_user_has_group_goods_group_goods3`
    FOREIGN KEY (`goods_id` )
    REFERENCES `hdgroup`.`group_goods` (`gid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '用户评论表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_comment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_comment` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_comment` (
  `user_id` INT UNSIGNED NOT NULL ,
  `goods_id` INT UNSIGNED NOT NULL ,
  `time` INT NOT NULL COMMENT '评论时间' ,
  `content` VARCHAR(255) NOT NULL COMMENT '评论内容' ,
  INDEX `fk_group_user_has_group_goods_group_goods3_idx` (`goods_id` ASC) ,
  INDEX `fk_group_user_has_group_goods_group_user3_idx` (`user_id` ASC) ,
  CONSTRAINT `fk_group_user_has_group_goods_group_user3`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_user_has_group_goods_group_goods3`
    FOREIGN KEY (`goods_id` )
    REFERENCES `hdgroup`.`group_goods` (`gid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '用户评论表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_cart`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_cart` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_cart` (
  `user_id` INT UNSIGNED NOT NULL ,
  `goods_id` INT UNSIGNED NOT NULL COMMENT '购物车表' ,
  `goods_num` SMALLINT NOT NULL COMMENT '商品数' ,
  INDEX `fk_group_user_has_group_goods_group_goods4_idx` (`goods_id` ASC) ,
  INDEX `fk_group_user_has_group_goods_group_user4_idx` (`user_id` ASC) ,
  CONSTRAINT `fk_group_user_has_group_goods_group_user4`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_user_has_group_goods_group_goods4`
    FOREIGN KEY (`goods_id` )
    REFERENCES `hdgroup`.`group_goods` (`gid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '用户购物车表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_collect`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_collect` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_collect` (
  `goods_id` INT UNSIGNED NOT NULL ,
  `user_id` INT UNSIGNED NOT NULL ,
  INDEX `fk_group_goods_has_group_user_group_user1_idx` (`user_id` ASC) ,
  INDEX `fk_group_goods_has_group_user_group_goods1_idx` (`goods_id` ASC) ,
  CONSTRAINT `fk_group_goods_has_group_user_group_goods1`
    FOREIGN KEY (`goods_id` )
    REFERENCES `hdgroup`.`group_goods` (`gid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_goods_has_group_user_group_user1`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '用户收藏表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_user_address`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_user_address` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_user_address` (
  `addressid` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `user_id` INT UNSIGNED NOT NULL ,
  `consignee` CHAR(20) NOT NULL ,
  `city` CHAR(20) NOT NULL COMMENT '市' ,
  `province` CHAR(12) NOT NULL COMMENT '省' ,
  `county` CHAR(12) NOT NULL COMMENT '县' ,
  `tel` CHAR(12) NOT NULL ,
  `street` VARCHAR(120) NOT NULL COMMENT '街道地址' ,
  `postcode` CHAR(10) NOT NULL ,
  PRIMARY KEY (`addressid`) ,
  INDEX `fk_group_user_address_group_user1_idx` (`user_id` ASC) ,
  CONSTRAINT `fk_group_user_address_group_user1`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '用户收货地址表，一个用户可以有多个收货地址';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_open_bind`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_open_bind` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_open_bind` (
  `user_id` INT UNSIGNED NOT NULL ,
  `openid` CHAR(64) NOT NULL ,
  `open_distinguish` TINYINT NOT NULL COMMENT '开发平台区别' ,
  `open_name` VARCHAR(16) NOT NULL COMMENT '开发平台名称' ,
  INDEX `fk_group_open_bind_group_user1_idx` (`user_id` ASC) ,
  UNIQUE INDEX `openid_UNIQUE` (`openid` ASC) ,
  CONSTRAINT `fk_group_open_bind_group_user1`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '站点用户与开发平台绑定表';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_userinfo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_userinfo` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_userinfo` (
  `user_id` INT UNSIGNED NOT NULL ,
  `balance` SMALLINT NOT NULL COMMENT '余额' ,
  `integral` SMALLINT NOT NULL COMMENT '积分' ,
  INDEX `fk_group_userinfo_group_user1_idx` (`user_id` ASC) ,
  CONSTRAINT `fk_group_userinfo_group_user1`
    FOREIGN KEY (`user_id` )
    REFERENCES `hdgroup`.`group_user` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = '用户信息表,用于保存用户账户余额，积分等数据';


-- -----------------------------------------------------
-- Table `hdgroup`.`group_goods_detail`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hdgroup`.`group_goods_detail` ;

CREATE  TABLE IF NOT EXISTS `hdgroup`.`group_goods_detail` (
  `goods_id` INT UNSIGNED NOT NULL ,
  `detail` TEXT NULL ,
  `goods_server` TINYINT NOT NULL ,
  INDEX `fk_table1_group_goods1_idx` (`goods_id` ASC) ,
  CONSTRAINT `fk_table1_group_goods1`
    FOREIGN KEY (`goods_id` )
    REFERENCES `hdgroup`.`group_goods` (`gid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

USE `hdgroup` ;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
