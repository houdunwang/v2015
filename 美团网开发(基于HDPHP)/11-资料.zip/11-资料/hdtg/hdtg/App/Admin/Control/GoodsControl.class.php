<?php
class GoodsControl extends  CommonControl{
	
	
	/**
	 * 添加商品的
	 */
	public function add(){
		if(IS_GET === true){
			$this->setShop();	 //设置当前商品对应的商铺
			$this->setCategory();//设置分类选择
			$this->setLocality();//设置地区选择
			$this->assign('goods_server',C('goods_server'));
			$this->display();
			exit;
		}
		
		
		
	}
	
	
	/**
	 * 分配当前商品对应商铺的信息
	 */
	private function setShop(){
		$shopid = $this->_get('shopid','intval');
		$db = K('shop');
		$shop = $db->getShopFind($shopid);		
		$this->assign('shop',$shop);
	}
	/**
	 * 设置分类选择的数据
	 */
	private function setCategory(){
		$db = K('category');
		$data = $db->getCategoryAll();
		$category = Data::channel($data,'cid','pid',0,0,2,'--');
		$this->assign('category',$category);
	}
	/**
	 * 设置地区的选择数据
	 */
	private function setLocality(){
		$db = K('locality');
		$data = $db->getLocalityAll();
		$locality = Data::channel($data,'lid','pid',0,0,2,'--');
		$this->assign('locality',$locality);
	}
	
	
	
	
	
	
	
}

















?>