<?php
class CartControl extends Control{
	/**
	 * 显示购物车页
	 */	
	public function index(){
		$this->display();
	}
}
?>