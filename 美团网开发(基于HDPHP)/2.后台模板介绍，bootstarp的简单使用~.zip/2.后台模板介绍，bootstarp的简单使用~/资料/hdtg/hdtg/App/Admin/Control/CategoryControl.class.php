<?php
class CategoryControl extends Control{
	
	
	
	/**
	 * 添加分类的方法
	 */
	public function add(){
		if(IS_GET === true){
			$this->display();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
}

















?>