<?php
   class DetailControl extends Control{
        public function index(){
        	$this->display();            
        }
   }
?>