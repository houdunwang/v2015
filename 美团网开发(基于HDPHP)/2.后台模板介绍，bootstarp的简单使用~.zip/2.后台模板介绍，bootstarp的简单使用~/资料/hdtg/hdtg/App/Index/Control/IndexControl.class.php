<?php
/**
 *	首页控制器 
 */
class IndexControl extends Control{
    function index(){
    	$this->display();
    }
}
?>