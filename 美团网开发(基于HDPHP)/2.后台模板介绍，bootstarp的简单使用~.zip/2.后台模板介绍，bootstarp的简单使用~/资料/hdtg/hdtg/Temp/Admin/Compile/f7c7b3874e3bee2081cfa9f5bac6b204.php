<?php if(!defined("HDPHP_PATH"))exit;C("SHOW_ERROR",false);?><?php if(!defined("HDPHP_PATH"))exit;C("SHOW_ERROR",false);?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
<script type='text/javascript' src='http://localhost/hdtg/hdphp/Extend/Org/Jquery/jquery-1.8.2.min.js'></script>
<link href="http://localhost/hdtg/hdphp/Extend/Org/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"><script src="http://localhost/hdtg/hdphp/Extend/Org/bootstrap/js/bootstrap.min.js"></script>
  <!--[if lte IE 6]>
  <link rel="stylesheet" type="text/css" href="http://localhost/hdtg/hdphp/Extend/Org/bootstrap/ie6/css/bootstrap-ie6.css">
  <![endif]-->
  <!--[if lte IE 7]>
  <link rel="stylesheet" type="text/css" href="http://localhost/hdtg/hdphp/Extend/Org/bootstrap/ie6/css/ie.css">
  <![endif]-->
<script type="text/javascript" src="http://localhost/hdtg/hdtg/App/Admin/Tpl/Public/js/common.js"> </script>
<link href="http://localhost/hdtg/hdtg/App/Admin/Tpl/Public/css/common.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="map">
	<span class='title'>分类列表</span>
</div>
<div id="content">
	<!--
	<div id="table-d">
		<ul class='hd'>
			<li></li>
			<li>分类名称</li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
	-->
	
	
	
	
	
	
	<table id="table" style="width:600px;" class='table table-striped table-bordered'>
		<thead>
			<tr>
				<th width="5%"></th>
				<th width="35%">栏目名称</th>
				<th width="35%"></th>
				<th ></th>
				<th></th>
			</tr>
		</thead>
		<tbody>
		<?php if(is_array($data)):?><?php  foreach($data as $k=>$v){ ?>
			<tr class="level_<?php echo $v['level'];?> pid_<?php echo $v['pid'];?>" cid="<?php echo $v['cid'];?>" level="<?php echo $v['level'];?>">
				<td><a class='btn btn-mini btn-info unfold' style="font-size:16px;" href="">+</a></td>
				<td>|-<?php echo $v['html'];?><?php echo $v['cname'];?></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
		<?php }?><?php endif;?>	
		</tbody>
	</table>
</div>
</body>
</html>