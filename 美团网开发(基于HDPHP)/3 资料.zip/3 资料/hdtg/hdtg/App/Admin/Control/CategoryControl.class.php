<?php
class CategoryControl extends CommonControl{
	
	public function __auto(){
		//实例模型
		$this->db = K('category');
	}
	
	/**
	 * 添加分类的方法
	 */
	public function add(){
		//$this->db->getCategoryAll();
		
		if(IS_GET === true){
			$this->display();
		}
	}
	
	public function edit(){
		
	}
	
	
	
	
	
	
	
	
	
	
	
}

















?>