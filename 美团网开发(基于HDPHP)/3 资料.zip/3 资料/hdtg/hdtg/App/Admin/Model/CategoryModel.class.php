<?php
class CategoryModel extends Model{
	
	
	
	
	/**
	 * 获得所有分类的数据
	 */
	public function getCategoryAll(){
		
	}
	
	
	
	
	
	
}













?>