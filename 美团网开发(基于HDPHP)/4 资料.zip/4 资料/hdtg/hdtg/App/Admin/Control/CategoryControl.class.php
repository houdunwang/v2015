<?php
class CategoryControl extends CommonControl{
	
	public function __auto(){
		//实例模型
		$this->db = K('category');
	}
	
	/**
	 * 添加分类的方法
	 */
	public function add(){
		//$this->db->getCategoryAll();
		
		if(IS_GET === true){
			$level = $this->db->getCategoryAll();
			$this->assign('level',$level);
			$this->display();
		}
		p($_POST);
		
	}
	
	public function edit(){
		
	}
	
	
	
	
	
	
	
	
	
	
	
}

















?>