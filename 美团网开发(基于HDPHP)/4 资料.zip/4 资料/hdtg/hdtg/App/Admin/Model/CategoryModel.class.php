<?php
class CategoryModel extends Model{
	//默认操作的表
	public $table = 'category';
	/**
	 * 获得所有分类的数据
	 */
	public function getCategoryAll(){
		return $this->select();
	}
	
	
	
	
	
	
}













?>