<?php

class IndexControl extends Control{

    
    /**
     * 用户收藏
     */
    public function collect(){
    	$this->display();
    }
    
    
}
?>