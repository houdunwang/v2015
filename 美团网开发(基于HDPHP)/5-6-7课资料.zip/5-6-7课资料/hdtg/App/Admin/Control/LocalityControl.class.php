<?php
class LocalityControl extends CommonControl{
	
	public function __auto(){
		$this->db = K('locality');
	}
	/**
	 * 显示地区
	 */
	public function index(){
		$data = $this->db->getLocalityAll();
		$data = Data::channel($data,'lid','pid',0,0,2,'--');
		$this->assign('data',$data);
		$this->display();
	}
	
	
	/**
	 * 添加地区
	 */
	public function add(){
		//如果是get请求,显示模板
		if(IS_GET === true){
			//分配用于选择的数据
			$data = $this->db->getLocalityAll();
		
			$level = Data::channel($data,'lid','pid',0,0,2,'--');
			$this->assign('level',$level);
			//显示模板
			$this->display();
			exit;
		}
		//获取提交的数据
		$data = $this->getData();
		//完成地区的添加
		if($this->db->addLocality($data)){
			$this->success('添加成功','index');
		}else{
			throw new Exception('添加失败!');
		}
	}
	
	
	/**
	 * 获取地区数据
	 */
	private function getData(){
		$data = array();
		$data['lname'] = $this->_post('lname','strip_targs');
		$data['sort'] = $this->_post('sort','intval');
		$data['display'] = $this->_post('display','intval');
		$data['pid'] = $this->_post('pid','intval');
		return $data;
	}
	
	
	
	
	
	
	
}




















?>