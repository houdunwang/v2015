<?php
class LocalityModel extends Model{
	
	public $table = 'locality';
	
	/***
	 * 查询所有的地区数据
	 */
	public function getLocalityAll(){
		return $this->select();
	}
	
	/**
	 * 添加地区
	 */
	public function addLocality($data){
		return $this->add($data);
	}
	
	
	
	
	
	
	
	
	
	
	
	
}














?>