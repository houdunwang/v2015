<?php
header('Content-type:text/html;charset=utf-8');
define('APP_GROUP','hdtg');
define('GROUP_PATH','./hdtg/');
define('DEBUG',true);
include './hdphp/hdphp.php';
?>