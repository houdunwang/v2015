<?php if(!defined("HDPHP_PATH"))exit;C("SHOW_ERROR",false);?>
	<div id="footer">
		<p>本demo不用于任何商业目的，仅供学习与交流</p>
	</div>
	</body>
</html>