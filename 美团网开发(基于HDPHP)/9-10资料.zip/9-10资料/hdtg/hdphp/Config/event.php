<?php
if (!defined("HDPHP_PATH"))
    exit('No direct script access allowed');
return array();