<?php
class LoginControl extends Control{
	/**
	 * 显示登录界面
	 */	
	public function index(){
		$this->display();
	}
	
	
	
	
}














?>