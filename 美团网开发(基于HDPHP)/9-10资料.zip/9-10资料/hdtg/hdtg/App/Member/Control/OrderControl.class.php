<?php
   class OrderControl extends Control{
        public function index(){
             $this->display();            
        }
   }
?>