<?php
class RegControl extends Control{
	/**
	 * 显示注册界面
	 */
	public function index(){
		$this->display();
	}
	
	
	
	
	
	
	
	
	
	
}















?>